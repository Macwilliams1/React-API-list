# React API List App

A simple React app that fetches data from a public API (**JSONPlaceholder**) and displays it in a reusable **ListComponent**.

---

## 🚀 Features
- Fetch users from JSONPlaceholder API.
- Manage loading and error states with `useState` and `useEffect`.
- Reusable `ListComponent` with customizable rendering.
- Handles empty lists gracefully.
- Clean UI with semantic HTML.

---

## 📂 Project Structure
```
react-api-list-app/
├── index.html
├── package.json
├── vite.config.js
├── src/
│   ├── App.jsx
│   ├── ListComponent.jsx
│   ├── main.jsx
│   ├── index.css
```

---

## 🛠️ Setup Instructions

### 1. Extract project
```bash
unzip react-api-list-app.zip
cd react-api-list-app
```

### 2. Install dependencies
```bash
npm install
```

### 3. Run development server
```bash
npm run dev
```

You will see output like:
```
VITE v5.2.0  ready in 300 ms

  ➜  Local:   http://localhost:5173/
```

### 4. Open in browser
Go to [http://localhost:5173/](http://localhost:5173/)

---

## 📌 Requirements
- Node.js v16+
- npm v8+

---

## 🎯 Example Behavior
- While fetching → `Loading users...`
- On success → Shows user list with names + emails.
- On error → Shows error message in red.
- If empty → `No users available`.

---

## 📄 License
This project is for educational purposes. Free to use and modify.
