import React from "react";

function ListComponent({ items, renderItem, emptyMessage = "No items found" }) {
  if (!items || items.length === 0) {
    return <p>{emptyMessage}</p>;
  }

  return (
    <ul>
      {items.map((item) => (
        <li key={item.id}>{renderItem(item)}</li>
      ))}
    </ul>
  );
}

export default ListComponent;
