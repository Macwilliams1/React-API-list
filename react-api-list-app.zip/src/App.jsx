import React, { useEffect, useState } from "react";
import ListComponent from "./ListComponent";

function App() {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // Fetch data when component mounts
  useEffect(() => {
    fetch("https://jsonplaceholder.typicode.com/users")
      .then((res) => {
        if (!res.ok) throw new Error("Failed to fetch users");
        return res.json();
      })
      .then((data) => {
        setUsers(data);
        setLoading(false);
      })
      .catch((err) => {
        setError(err.message);
        setLoading(false);
      });
  }, []);

  if (loading) return <p>Loading users...</p>;
  if (error) return <p style={{ color: "red" }}>Error: {error}</p>;

  return (
    <main>
      <h1>User List</h1>
      <ListComponent
        items={users}
        renderItem={(user) => (
          <div>
            <strong>{user.name}</strong> <br />
            <small>{user.email}</small>
          </div>
        )}
        emptyMessage="No users available"
      />
    </main>
  );
}

export default App;
